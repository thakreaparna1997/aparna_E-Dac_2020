class Que11
{
	public static void main(String args[])
	{
		double r=7.5d;
		double pi=3.14d;
		double area, perimeter;
		area= pi*r*r;
		perimeter=2*pi*r;
		System.out.println("Area is = "+area);
		System.out.println("perimeter is = "+perimeter);
	}
}
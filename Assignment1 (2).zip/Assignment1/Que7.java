class Que7
{
	public static void main(String args[])
	{
		int a=8;
		System.out.println("8*1= "+a*1);
		System.out.println("8*2= "+a*2);
		System.out.println("8*3= "+a*3);	
		System.out.println("8*4= "+a*4);
		System.out.println("8*5= "+a*5);
		System.out.println("8*6= "+a*6);
		System.out.println("8*7= "+a*7);
		System.out.println("8*8= "+a*8);
		System.out.println("8*9= "+a*9);
		System.out.println("8*10= "+a*10);
	}
}
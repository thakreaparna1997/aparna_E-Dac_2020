class Que6
{
	public static void main(String args[])
	{
		int a=125,b=24;
		System.out.println("125+24= "+(a+b));
		System.out.println("125-24= "+(a-b));
		System.out.println("125*24= "+a*b);
		System.out.println("125/24= "+a/b);
		System.out.println("125mod24= "+a%b);
	}
}
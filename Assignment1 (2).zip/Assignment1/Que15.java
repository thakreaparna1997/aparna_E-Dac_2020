import java.util.Scanner;
class Que15
{
	public static void main(String args[])
	{
		int x,y,t;
		Scanner sc = new Scanner(System.in);  
       		System.out.println("Enter the value of X and Y");  
      		 x = sc.nextInt();  
      		 y = sc.nextInt();  
		sc.close();
		t=x;
		x=y;
		y=t;
		System.out.println("after swap  "+x);	
		System.out.println(y);	
	}
}
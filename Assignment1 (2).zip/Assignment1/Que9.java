class Que9
{
	public static void main(String args[])
	{
		double a=25.5d,b=3.5d,c=40.5,e=4.5d;
		double result;
		result=(a*b-b*b)/(c-e);
		System.out.println(result);
		
	}
}
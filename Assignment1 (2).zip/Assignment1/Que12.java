import java.util.Scanner;
class Que12
{
	public static void main(String args[])
	{
		int a,b,c;
		double avg;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first number");
		a=sc.nextInt();
		System.out.println("enter second number");
		b=sc.nextInt();
		System.out.println("enter third number");
		c=sc.nextInt();
		sc.close();
		avg=(a+b+c)/3;
		System.out.println("average= "+avg);
		
				
	}
}
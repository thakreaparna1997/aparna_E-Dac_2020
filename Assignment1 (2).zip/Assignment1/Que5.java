class Que5
{
	public static void main(String args[])
	{
		int num1=25,num2=5;
		System.out.println("25*5= "+num1*num2);
	}
}
class Que13
{
	public static void main(String args[])
	{
		double width=5.5d,height=8.5d;
		double area,perimeter;
		area=width*height;
		perimeter=2*(width+height);
		System.out.println("Area is 5.5*8.5= "+area);
		System.out.println("perimeter is 2*(5.5+8.5)= "+perimeter);
	}
}
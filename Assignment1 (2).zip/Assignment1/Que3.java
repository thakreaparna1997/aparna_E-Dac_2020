class  Que3
{
	public static void main(String args[])
	{
		int a=50,b=3;
		int ans=a/b;
		System.out.println(ans);

	}
}
	
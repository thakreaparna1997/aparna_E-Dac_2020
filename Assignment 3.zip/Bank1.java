import java.util.Scanner;

class Bank{
	private String accno;
	private String name;
	private long balance;

	Scanner a= new Scanner(System.in);
	void openAccount()
	{
		System.out.print("Enter Account no.: ");
		accno=a.next();
		System.out.print("Enter Name: ");
		name=a.next();
		System.out.print("Enter Balance: ");
		balance=a.nextLong();
	}
	void show()
	{
		System.out.println("Account no= "+accno);
		System.out.println("Name= "+name);
		System.out.println("Balance Amount= "+balance);


	}	
	void deposit()
	{
		long amt;
	System.out.println("Enter Amount you want to Deposit: ");
	amt= a.nextLong();
	balance= balance + amt;
	}
	
	void withdrawal()
	{
		long amt;
		System.out.println("Enter Amount you want to withdraw: ");
		amt = a.nextLong();
		if(balance >= amt)
		{
			balance= balance - amt;
		} 
		else
		{
			System.out.println("Less Balance..... Transaction Failed ");

		}
	}
	boolean search(String acn)
	{
		if(accno.equals(acn))
		{
			show();
			return(true);
		}
		else
		{
			return(false);
		}
	}
}

public class Bank1{
	public static void main(String args[])
	{
		Scanner a=new Scanner(System.in);
		System.out.print("How many customers you want to enter: ");
		int n= a.nextInt();
		Bank C[]= new Bank[n];
		for(int i=0;i<C.length;i++)
		{
			C[i]= new Bank();
			C[i].openAccount();
		}	
	int ch;
        do {
            System.out.println("Main Menu ");
	System.out.println("1. Display all Account: ");
	System.out.println("2. Check Balance:  ");
	System.out.println("3. Deposit : ");
	System.out.println("4. Withdraw: ");
	System.out.println("5. Exit");
            System.out.println("Enter Your Choice :"); 
	ch = a.nextInt();
                switch (ch) {
                    case 1:
                        for (int i = 0; i < C.length; i++) {
                            C[i].show();
                        }
                        break;

                    case 2:
                        System.out.print("Enter Account No You Want to Search...: ");
                        String acn = a.next();
                        boolean found = false;
                        for (int i = 0; i < C.length; i++) {
                            found = C[i].search(acn);
                            if (found) {
                                break;
                            }
                        }
                        if (!found) {
                            System.out.println("Search Failed..Account Not Exist..");
                        }
                        break;

                    case 3:
                        System.out.println("Enter Account No : ");
                        acn = a.next();
                        found = false;
                        for (int i = 0; i < C.length; i++) {
                            found = C[i].search(acn);
                            if (found) {
                                C[i].deposit();
                                break;
                            }
                        }
                        if (!found) {
                            System.out.println("Search Failed..Account Not Exist..");
                        }
                        break;

                    case 4:
                        System.out.print("Enter Account No : ");
                        acn = a.next();
                        found = false;
                        for (int i = 0; i < C.length; i++) {
                            found = C[i].search(acn);
                            if (found) {
                                C[i].withdrawal();
                                break;
                            }
                        }
                        if (!found) {
                            System.out.println("Search Failed..Account Not Exist..");
                        }
                        break;

                    case 5:
                        System.out.println("Good Bye..");
                        break;
                }
            }
            while (ch != 5);
        }
    }
		




/*Sort a ten element array in descending order.*/
import java.util.*;
class Que7{    
    public static void main(String[] args) {            
        Scanner sc=new Scanner(System.in);
	
	     
        int temp = 0;       
        System.out.println("Elements of original array: "); 
int[] a=new int[10];   
        for (int i = 0; i <= 10; i++) {  
		a[i] = sc.nextInt();   
            System.out.print(a[i] + " ");    
        }    
               
        for (int i = 0; i <= 10; i++) {     
            for (int j = i+1; j <= 10; j++) {     
               if(a[i] < a[j]) {    
                   temp = a[i];    
                   a[i] = a[j];    
                   a[j] = temp;    
               }     
            }     
        }    
            
        System.out.println();       
        System.out.println("Elements of array sorted in descending order: ");    
        for (int i = 0; i <= 10; i++) {     
            System.out.println(a[i] + " ");    
        }    
    }    
}    
class Que5{ 
   public static void main (String args[])   
 {       
 int odd=1;       
 int sp=8;        
for (int i=1; i<=9;i++)       
 {           
 for (int j=1;j<=sp;j++)         
   {           
 System.out.print("  ");           
 }          
  int k=0;           
 for (int j=9;j>=odd;j--)           
 {             
   if (j>=i)              
  {               
 k++;               
 }                
else               
 {               
 k--;                
}            
System.out.print(k +" ");           
 }           
 odd=odd+2;            
System.out.println();          
  sp--;       
 }   
 }
}
